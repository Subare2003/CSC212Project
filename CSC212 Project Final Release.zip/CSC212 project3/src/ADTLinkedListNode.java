// node class
public class ADTLinkedListNode<T> {
   public T data;
   public ADTLinkedListNode<T> next;
   
   
   public ADTLinkedListNode () {
   data = null;
   next = null;}
   
public ADTLinkedListNode (T val) {
data = val;
next = null;
}

}