
public class Order {
	
	public enum order{preOrder, inOrder, postOrder};
}
