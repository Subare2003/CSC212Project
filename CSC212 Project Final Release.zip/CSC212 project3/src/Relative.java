
public class Relative {

	public enum relative{
		Root, Parent, LeftChild, RightChild
		};
}
